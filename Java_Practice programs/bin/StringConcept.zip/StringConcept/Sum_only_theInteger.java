package StringConcept;

public class Sum_only_theInteger {

	public static void main(String[] args) {
		String name="automation1234Testing";
		String result="";
		
		result = name.replaceAll("\\d+", "10");
System.out.println(result);
System.out.println("automation"+(1+2+3+4)+"testing");
	}

}
