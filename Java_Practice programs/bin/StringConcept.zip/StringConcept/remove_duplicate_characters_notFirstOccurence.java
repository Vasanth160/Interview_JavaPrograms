package StringConcept;

import java.util.LinkedHashSet;

public class remove_duplicate_characters_notFirstOccurence {
	public static void main(String[] args) {
		
//		String input="Vasanth QA";
//		LinkedHashSet<Character> se=new LinkedHashSet<Character>();
//		LinkedHashSet<Character> seen=new LinkedHashSet<Character>();
//		//StringBuilder s=new StringBuilder();
//		//String name=input.substring(0, 9)+input.substring(9, 10).toLowerCase();
//		
//		char[] charArray = input.toCharArray();
//		
//		for (char c : charArray) {
//			if(!se.contains(c)) {
//				se.add(c);
//				//s.append(c);
//			}
//		}
//		for (char c : se) {
//			System.out.print(c);
//		}
//		System.out.println();
//		
//		String Myname="Vasanth";
//		
//		char[] charArray2 = Myname.toCharArray();
//		for (char c : charArray2) {
//			if(!seen.contains(c))
//				seen.add(c);
//		}
//		System.out.print("Final output ");
//		for (char value : seen) {
//			System.out.print(value);
//		}
		String input = "Vasanth QA";
		LinkedHashSet<Character> seen=new LinkedHashSet<Character>();
        StringBuilder output = new StringBuilder();

        for (int i = 0; i < input.length(); i++) {
            char ch = input.charAt(i);
            char lowerCase = Character.toLowerCase(ch);
            if (!seen.contains(lowerCase)) {
                seen.add(ch);
                output.append(ch);
            }
        }
       // System.out.println(output.toString());
        

        for (Character character : seen) {
			System.out.print(character);
		}
    }
	
	}


