package StringConcept;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Count_theDuplicateCharacter_fromString {

	public static void main(String[] args) {
//				Scanner sc=new Scanner(System.in);
//				System.out.println("Enter the String");
//				String name=sc.nextLine();
				String name="aaabbbccc";
				char[] ca = name.toCharArray();
				Map<Character, Integer>mp=new HashMap<Character, Integer>();
				for (char c : ca) {
					if(mp.containsKey(c))
						mp.put(c, mp.get(c)+1);
					else
						mp.put(c,1);
				}
				
				Set<Entry<Character, Integer>> entrySet = mp.entrySet();
				for (Entry<Character, Integer> entry : entrySet) {
					if(entry.getValue()>1||entry.getValue()==1)
						System.out.println(entry.getKey()+" "+ entry.getValue());
				}


//		String name="Vasanth QA";
//		String lowerCase =name.substring(0, 9)+ name.substring(9, 10).toLowerCase();
//		char[] ch = lowerCase.toCharArray();
//		Map<Character, Integer> mp=new LinkedHashMap();
//		for (char c : ch) {
//			if(mp.containsKey(c)){
//				mp.put(c, mp.get(c)+1);}
//			else
//				mp.put(c, 1);
//		}
//		 
//			
//		System.out.print("After Removing Duplicate Character ");
//		Set<Entry<Character, Integer>> entrySet = mp.entrySet();
//		for (Entry<Character, Integer> entry : entrySet) {
//			if(entry.getValue()>1)
//				System.out.print(entry.getKey());
//		}

	}
}


















//char a[]= {'a','b','a','c','b','b'};//Find Dulpicate Char
//		char[] ch = name.toCharArray();
//		Map<Character, Integer> mp=new HashMap<Character, Integer>();
//		for (Character c : ch) {
//			if(mp.containsKey(c))
//				mp.put(c, mp.get(c)+1);
//			else
//				mp.put(c, 1);
//		}
//
//		
//		Set<Entry<Character, Integer>> entrySet = mp.entrySet();
//		System.out.println("Duplicate character in the Given string ");
//		//System.out.println("Unique values are ");
//		for (Entry<Character, Integer> entry : entrySet) {
////			//This line will print the Duplicate value
//			if(entry.getValue()>1)
//				System.out.println(entry.getKey()+" is present for "+entry.getValue()+" times");

//This line will print the Unique value
//			if(entry.getValue()==1)
//				System.out.print(entry.getKey()+" ");		}




